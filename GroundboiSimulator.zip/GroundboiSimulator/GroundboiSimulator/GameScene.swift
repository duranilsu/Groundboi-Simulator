//
//  GameScene.swift
//  GroundboiSimulator
//
//  Created by Datta, Nishant on 11/9/21.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    //we have an array of holes and a label for game score
    var slots = [Holes]()
    var gameScore: SKLabelNode!
    
    var popupTime = 1.05
    var numRounds = 0
    
    var score = 0 {
        didSet {
            gameScore.text = "score: \(score)"
        }
    }
    
    //this function puts the holes on the screen
    func putHole(at position: CGPoint) {
        let slot = Holes()
        slot.placeOnScreen(at: position)
        addChild(slot)
        slots.append(slot)
    }
    

    override func didMove(to view: SKView) {
        
        //add background to screen
        let background = SKSpriteNode(imageNamed: "background")
        background.position = CGPoint(x: 512, y: 384)
        background.blendMode = .replace
        background.zPosition = -1
        addChild(background)
        
        //add game score on screen
        gameScore =  SKLabelNode(fontNamed: "Comic Sans")
        gameScore.text = "Score: 0"
        gameScore.position = CGPoint(x: 8, y: 8)
        gameScore.horizontalAlignmentMode = .left
        gameScore.fontSize = 48
        addChild(gameScore)
        
        //we put the holes in order
        for i in 0..<5 {
           putHole(at: CGPoint(x: 100 + (i * 170), y: 230))
       }
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        let tappedNodes = nodes(at: location)
    }

    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}

