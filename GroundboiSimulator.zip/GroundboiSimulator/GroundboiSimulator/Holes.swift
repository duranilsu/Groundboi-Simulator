//
//  Holes.swift
//  GroundboiSimulator
//
//  Created by Datta, Nishant on 11/9/21.
//

import UIKit
import SpriteKit

//this file will display assets and animations on the screen

class Holes: SKNode {
    
    var groundNode: SKSpriteNode!
    var holeImage: SKSpriteNode!
    var isVisible = false
    
    func placeOnScreen(at position: CGPoint) {
    
        let cropNode = SKCropNode()
        cropNode.position = CGPoint(x: 0, y: 25)
        cropNode.zPosition = 1
        cropNode.maskNode = SKSpriteNode(imageNamed: "whackm") //change
        
        self.position = position
        holeImage = SKSpriteNode(imageNamed: "image") //change later
        addChild(holeImage)
        
        groundNode = SKSpriteNode(imageNamed: "cutegroundboi")//change
        groundNode.position = CGPoint(x: 0, y: -70)
        groundNode.name = "charboi"
        cropNode.addChild(groundNode)
        addChild(cropNode)
    }
    
    func show(hideTime: Double) {
        if isVisible {
            return
        }
        //character will display upon clicking
        groundNode.xScale = 1
        groundNode.yScale = 1
        groundNode.run(SKAction.moveBy(x: 0, y: 70, duration: 0.07))
        isVisible = true
        
        
        let m = Int.random(in: 0...2)
        if m == 0 {
            groundNode.texture = SKTexture(imageNamed: "cutegroundboi")
        } else if m == 1 {
            groundNode.texture =
                SKTexture(imageNamed: "uglyrocky")
    }
    
    }
    
    
}
