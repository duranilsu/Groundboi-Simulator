//
//  GameScene.swift
//  GroundboiSimulator
//
//  Created by Datta, Nishant on 11/9/21.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    

    // All sprites created within GameScene.sks
    
    private var hole1 : SKSpriteNode?
    private var hole2 : SKSpriteNode?
    private var hole3 : SKSpriteNode?

    private var groundboi1 : SKSpriteNode?
    private var groundboi2 : SKSpriteNode?
    private var groundboi3 : SKSpriteNode?
    
    private var rocky1 : SKSpriteNode?
    private var rocky2 : SKSpriteNode?
    private var rocky3 : SKSpriteNode?
    
    private var scoreLabel : SKLabelNode?
    private var scoreValLabel: SKLabelNode?
    
    private var showingResults : Bool = false       // are the contents of the holes currently being displayed?
    private var holeContents: [Int] = [0, 1, 2]     // contain values that determine the contents of each hole - 0: empty, 1: groundboi, 2: rocky
    
    var score = 0 {
        didSet {
            scoreValLabel?.text = score.description
        }
    }
    
    // Initialize SKSprite optional variables
    override func didMove(to view: SKView) {
        
        // Find hole sprites
        self.hole1 = self.childNode(withName: "//hole1") as? SKSpriteNode
        self.hole2 = self.childNode(withName: "//hole2") as? SKSpriteNode
        self.hole3 = self.childNode(withName: "//hole3") as? SKSpriteNode
        
        // Find groundboi sprites
        self.groundboi1 = self.childNode(withName: "//groundboi1") as? SKSpriteNode
        self.groundboi2 = self.childNode(withName: "//groundboi2") as? SKSpriteNode
        self.groundboi3 = self.childNode(withName: "//groundboi3") as? SKSpriteNode
        
        // Find rocky sprites
        self.rocky1 = self.childNode(withName: "//rocky1") as? SKSpriteNode
        self.rocky2 = self.childNode(withName: "//rocky2") as? SKSpriteNode
        self.rocky3 = self.childNode(withName: "//rocky3") as? SKSpriteNode
        
        // Get score label and score value labels
        self.scoreLabel = self.childNode(withName: "//scoreLabel") as? SKLabelNode
        self.scoreValLabel = self.childNode(withName: "//scoreValLabel") as? SKLabelNode
        
        // Set groundboi and rocky sprites' alpha values to 0
        self.groundboi1?.alpha = 0
        self.rocky1?.alpha = 0
        self.groundboi2?.alpha = 0
        self.rocky2?.alpha = 0
        self.groundboi3?.alpha = 0
        self.rocky3?.alpha = 0
        
        // Randomize order of
        holeContents.shuffle()
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if (showingResults) {
            self.groundboi1?.alpha = self.groundboi1?.alpha != 0 ? 0 : 0
            self.groundboi2?.alpha = self.groundboi2?.alpha != 0 ? 0 : 0
            self.groundboi3?.alpha = self.groundboi3?.alpha != 0 ? 0 : 0
            self.rocky1?.alpha = self.rocky1?.alpha != 0 ? 0 : 0
            self.rocky2?.alpha = self.rocky2?.alpha != 0 ? 0 : 0
            self.rocky3?.alpha = self.rocky3?.alpha != 0 ? 0 : 0
            holeContents.shuffle()
            showingResults = false
        }
        else {
            for touch in touches {
                let location = touch.location(in: self)

                // if the first hole is clicked
                if let inHole1 = self.hole1?.contains(location) {
                    if inHole1 {
                        revealResults()
                        showingResults = true
                        
                        // adjust score based on contents of chosen hole
                        if holeContents[0] == 1 { score += 3 }
                        else if holeContents[0] == 2 { score -= 1 }
                        
                    }
                }
                
                // if the second hole is clicked
                if let inHole2 = self.hole2?.contains(location) {
                    if inHole2 {
                        revealResults()
                        showingResults = true
                        
                        // adjust score based on contents of chosen hole
                        if holeContents[1] == 1 { score += 3 }
                        else if holeContents[1] == 2 { score -= 1 }
                        
                    }
                }
                
                // if the third hole is clicked
                if let inHole3 = self.hole3?.contains(location) {
                    if inHole3 {
                        revealResults()
                        showingResults = true
                        
                        // adjust score based on contents of chosen hole
                        if holeContents[2] == 1 { score += 3 }
                        else if holeContents[2] == 2 { score -= 1 }
                        
                    }
                }
                
            }


        }
    }

    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
    
    func revealResults() {
        
        // if hole1 contains the groundboi
        if (holeContents[0] == 1) {
            
            self.groundboi1?.alpha = 1
            if (holeContents[1] == 2) {
                self.rocky2?.alpha = 1
            }
            else {
                self.rocky3?.alpha = 1
            }
        }
        
        // if hole2 contains the groundboi
        else if (holeContents[1] == 1) {
            
            self.groundboi2?.alpha = 1
            if (holeContents[2] == 2) {
                self.rocky3?.alpha = 1
            }
            else {
                self.rocky1?.alpha = 1
            }
        }
        
        // if hole3 contains the groundboi
        else {
            
            self.groundboi3?.alpha = 1
            
            if (holeContents[0] == 2) {
                self.rocky1?.alpha = 1
            }
            else {
                self.rocky2?.alpha = 1
            }
        }
    }
}

